clc
clear

load('..\dp\energyArrayDPvaryingTaskNumSingleServer');
load('..\dp\succArrayDPvaryingTaskNumSingleServer');
load('..\dp\comTimeArrayDPvaryingTaskNumSingleServer');

load('..\dpRuntime\energyArrayDPRuntimeVaryingTaskNumSingleServer');
load('..\dpRuntime\succArrayDPRuntimeVaryingTaskNumSingleServer');
load('..\dpRuntime\comTimeArrayDPRuntimeVaryingTaskNumSingleServer');

load('..\random\energyArrayRandomVaryingTaskNumSingleServer');
load('..\random\succArrayRandomVaryingTaskNumSingleServer');
load('..\random\comTimeArrayRandomVaryingTaskNumSingleServer');

load('..\greedy1\energyArrayGreedy1VaryingTaskNumSingleServer');
load('..\greedy1\succArrayGreedy1VaryingTaskNumSingleServer');
load('..\greedy1\comTimeArrayGreedy1VaryingTaskNumSingleServer');

load('..\greedy2\energyArrayGreedy2VaryingTaskNumSingleServer');
load('..\greedy2\succArrayGreedy2VaryingTaskNumSingleServer');
load('..\greedy2\comTimeArrayGreedy2VaryingTaskNumSingleServer');

succArray1 = succArrayDPvaryingTaskNumSingleServer.*succArrayDPRuntimeVaryingTaskNumSingleServer.*succArrayGreedy1VaryingTaskNumSingleServer.*succArrayGreedy2VaryingTaskNumSingleServer;
succArray2 = succArrayDPvaryingTaskNumSingleServer.*succArrayDPRuntimeVaryingTaskNumSingleServer.*succArrayGreedy2VaryingTaskNumSingleServer;

meanEnergyDPvaryingTaskNumSingleServer = sum(energyArrayDPvaryingTaskNumSingleServer.*succArray1, 2)./sum(succArray1, 2);
meanEnergyDPRuntimeVaryingTaskNumSingleServer = sum(energyArrayDPRuntimeVaryingTaskNumSingleServer.*succArray1, 2)./sum(succArray1, 2);
meanEnergyRandomVaryingTaskNumSingleServer = sum(energyArrayRandomVaryingTaskNumSingleServer.*succArrayRandomVaryingTaskNumSingleServer, 2)./sum(succArrayRandomVaryingTaskNumSingleServer, 2);
meanEnergyGreedy1VaryingTaskNumSingleServer = sum(energyArrayGreedy1VaryingTaskNumSingleServer.*succArray1, 2)./sum(succArray1, 2);
meanEnergyGreedy2VaryingTaskNumSingleServer = sum(energyArrayGreedy2VaryingTaskNumSingleServer.*succArray1, 2)./sum(succArray1, 2);

meanComTimeDPvaryingTaskNumSingleServer = sum(comTimeArrayDPvaryingTaskNumSingleServer.*succArrayDPvaryingTaskNumSingleServer, 2)./sum(succArrayDPvaryingTaskNumSingleServer, 2);
meanComTimeDPRuntimeVaryingTaskNumSingleServer = sum(comTimeArrayDPRuntimeVaryingTaskNumSingleServer.*succArrayDPRuntimeVaryingTaskNumSingleServer, 2)./sum(succArrayDPRuntimeVaryingTaskNumSingleServer, 2);
meanComTimeRandomVaryingTaskNumSingleServer = sum(comTimeArrayRandomVaryingTaskNumSingleServer.*succArrayRandomVaryingTaskNumSingleServer, 2)./sum(succArrayRandomVaryingTaskNumSingleServer, 2);
meanComTimeGreedy1VaryingTaskNumSingleServer = sum(comTimeArrayGreedy1VaryingTaskNumSingleServer.*succArrayGreedy1VaryingTaskNumSingleServer, 2)./sum(succArrayGreedy1VaryingTaskNumSingleServer, 2);
meanComTimeGreedy2VaryingTaskNumSingleServer = sum(comTimeArrayGreedy2VaryingTaskNumSingleServer.*succArrayGreedy2VaryingTaskNumSingleServer, 2)./sum(succArrayGreedy2VaryingTaskNumSingleServer, 2);

meanEnergyResult = [(2:2:20)', meanEnergyDPvaryingTaskNumSingleServer, meanEnergyDPRuntimeVaryingTaskNumSingleServer, ...
    meanEnergyRandomVaryingTaskNumSingleServer, meanEnergyGreedy1VaryingTaskNumSingleServer, meanEnergyGreedy2VaryingTaskNumSingleServer];
succResult = [(2:2:20)', sum(succArrayDPvaryingTaskNumSingleServer, 2), sum(succArrayDPRuntimeVaryingTaskNumSingleServer, 2), ...
    sum(succArrayRandomVaryingTaskNumSingleServer, 2), sum(succArrayGreedy1VaryingTaskNumSingleServer, 2), sum(succArrayGreedy2VaryingTaskNumSingleServer, 2), ];
meanComTimeResult = [(2:2:20)', meanComTimeDPvaryingTaskNumSingleServer, meanComTimeDPRuntimeVaryingTaskNumSingleServer, ...
    meanComTimeRandomVaryingTaskNumSingleServer, meanComTimeGreedy1VaryingTaskNumSingleServer, meanComTimeGreedy2VaryingTaskNumSingleServer];

meanEnergyDPvaryingTaskNumSingleServer = sum(energyArrayDPvaryingTaskNumSingleServer.*succArray2, 2)./sum(succArray2, 2);
meanEnergyDPRuntimeVaryingTaskNumSingleServer = sum(energyArrayDPRuntimeVaryingTaskNumSingleServer.*succArray2, 2)./sum(succArray2, 2);
meanEnergyRandomVaryingTaskNumSingleServer = sum(energyArrayRandomVaryingTaskNumSingleServer.*succArrayRandomVaryingTaskNumSingleServer, 2)./sum(succArrayRandomVaryingTaskNumSingleServer, 2);
meanEnergyGreedy1VaryingTaskNumSingleServer = sum(energyArrayGreedy1VaryingTaskNumSingleServer.*succArray2, 2)./sum(succArray2, 2);
meanEnergyGreedy2VaryingTaskNumSingleServer = sum(energyArrayGreedy2VaryingTaskNumSingleServer.*succArray2, 2)./sum(succArray2, 2);
meanEnergyResult2 = [(2:2:20)', meanEnergyDPvaryingTaskNumSingleServer, meanEnergyDPRuntimeVaryingTaskNumSingleServer, ...
    meanEnergyRandomVaryingTaskNumSingleServer, meanEnergyGreedy1VaryingTaskNumSingleServer, meanEnergyGreedy2VaryingTaskNumSingleServer];
%%
clc
clear
load('..\dp\energyArrayDPvaryingIntervalCountSingleServer');
load('..\dp\succArrayDPvaryingIntervalCountSingleServer');
load('..\dp\comTimeArrayDPvaryingIntervalCountSingleServer');

load('..\dpRuntime\energyArrayDPRuntimeVaryingIntervalCountSingleServer');
load('..\dpRuntime\succArrayDPRuntimeVaryingIntervalCountSingleServer');
load('..\dpRuntime\comTimeArrayDPRuntimeVaryingIntervalCountSingleServer');

load('..\random\energyArrayRandomVaryingIntervalCountSingleServer');
load('..\random\succArrayRandomVaryingIntervalCountSingleServer');
load('..\random\comTimeArrayRandomVaryingIntervalCountSingleServer');

load('..\greedy1\energyArrayGreedy1VaryingIntervalCountSingleServer');
load('..\greedy1\succArrayGreedy1VaryingIntervalCountSingleServer');
load('..\greedy1\comTimeArrayGreedy1VaryingIntervalCountSingleServer');

load('..\greedy2\energyArrayGreedy2VaryingIntervalCountSingleServer');
load('..\greedy2\succArrayGreedy2VaryingIntervalCountSingleServer');
load('..\greedy2\comTimeArrayGreedy2VaryingIntervalCountSingleServer');

succArray = succArrayDPvaryingIntervalCountSingleServer.*succArrayDPRuntimeVaryingIntervalCountSingleServer.*succArrayGreedy2VaryingIntervalCountSingleServer.*succArrayGreedy1VaryingIntervalCountSingleServer;


meanEnergyDPvaryingIntervalCountSingleServer = sum(energyArrayDPvaryingIntervalCountSingleServer.*succArray, 2)./sum(succArray, 2);
meanEnergyDPRuntimeVaryingIntervalCountSingleServer = sum(energyArrayDPRuntimeVaryingIntervalCountSingleServer.*succArray, 2)./sum(succArray, 2);
meanEnergyRandomVaryingIntervalCountSingleServer = sum(energyArrayRandomVaryingIntervalCountSingleServer.*succArrayRandomVaryingIntervalCountSingleServer, 2)./sum(succArrayRandomVaryingIntervalCountSingleServer, 2);
meanEnergyGreedy1VaryingIntervalCountSingleServer = sum(energyArrayGreedy1VaryingIntervalCountSingleServer.*succArray, 2)./sum(succArray, 2);
meanEnergyGreedy2VaryingIntervalCountSingleServer = sum(energyArrayGreedy2VaryingIntervalCountSingleServer.*succArray, 2)./sum(succArray, 2);

meanComTimeDPvaryingIntervalCountSingleServer = sum(comTimeArrayDPvaryingIntervalCountSingleServer.*succArrayGreedy1VaryingIntervalCountSingleServer, 2)./sum(succArrayGreedy1VaryingIntervalCountSingleServer, 2);
meanComTimeDPRuntimeVaryingIntervalCountSingleServer = sum(comTimeArrayDPRuntimeVaryingIntervalCountSingleServer.*succArrayGreedy1VaryingIntervalCountSingleServer, 2)./sum(succArrayGreedy1VaryingIntervalCountSingleServer, 2);
meanComTimeRandomVaryingIntervalCountSingleServer = sum(comTimeArrayRandomVaryingIntervalCountSingleServer.*succArrayRandomVaryingIntervalCountSingleServer, 2)./sum(succArrayRandomVaryingIntervalCountSingleServer, 2);
meanComTimeGreedy1VaryingIntervalCountSingleServer = sum(comTimeArrayGreedy1VaryingIntervalCountSingleServer.*succArrayGreedy1VaryingIntervalCountSingleServer, 2)./sum(succArrayGreedy1VaryingIntervalCountSingleServer, 2);
meanComTimeGreedy2VaryingIntervalCountSingleServer = sum(comTimeArrayGreedy2VaryingIntervalCountSingleServer.*succArrayGreedy1VaryingIntervalCountSingleServer, 2)./sum(succArrayGreedy1VaryingIntervalCountSingleServer, 2);

meanEnergyResult = [(10:10:100)', meanEnergyDPvaryingIntervalCountSingleServer, meanEnergyDPRuntimeVaryingIntervalCountSingleServer, ...
    meanEnergyRandomVaryingIntervalCountSingleServer, meanEnergyGreedy1VaryingIntervalCountSingleServer, meanEnergyGreedy2VaryingIntervalCountSingleServer];
succResult = [(10:10:100)', sum(succArrayDPvaryingIntervalCountSingleServer, 2), sum(succArrayDPRuntimeVaryingIntervalCountSingleServer, 2), ...
    sum(succArrayRandomVaryingIntervalCountSingleServer, 2), sum(succArrayGreedy1VaryingIntervalCountSingleServer, 2), sum(succArrayGreedy2VaryingIntervalCountSingleServer, 2), ];
meanComTimeResult = [(10:10:100)', meanComTimeDPvaryingIntervalCountSingleServer, meanComTimeDPRuntimeVaryingIntervalCountSingleServer, ...
    meanComTimeRandomVaryingIntervalCountSingleServer, meanComTimeGreedy1VaryingIntervalCountSingleServer, meanComTimeGreedy2VaryingIntervalCountSingleServer];
%%
clc
clear
load('..\dp\energyArrayDPvaryingVCPUSingleServer');
load('..\dp\succArrayDPvaryingVCPUSingleServer');
load('..\dp\comTimeArrayDPvaryingVCPUSingleServer');

load('..\dpRuntime\energyArrayDPRuntimeVaryingVCPUSingleServer');
load('..\dpRuntime\succArrayDPRuntimeVaryingVCPUSingleServer');
load('..\dpRuntime\comTimeArrayDPRuntimeVaryingVCPUSingleServer');

load('..\random\energyArrayRandomVaryingVCPUSingleServer');
load('..\random\succArrayRandomVaryingVCPUSingleServer');
load('..\random\comTimeArrayRandomVaryingVCPUSingleServer');

load('..\greedy1\energyArrayGreedy1VaryingVCPUSingleServer');
load('..\greedy1\succArrayGreedy1VaryingVCPUSingleServer');
load('..\greedy1\comTimeArrayGreedy1VaryingVCPUSingleServer');

load('..\greedy2\energyArrayGreedy2VaryingVCPUSingleServer');
load('..\greedy2\succArrayGreedy2VaryingVCPUSingleServer');
load('..\greedy2\comTimeArrayGreedy2VaryingVCPUSingleServer');

succArray = succArrayDPvaryingVCPUSingleServer(5:5:end, :).*succArrayDPRuntimeVaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer.*succArrayGreedy2VaryingVCPUSingleServer;

meanEnergyDPvaryingVCPUSingleServer = sum(energyArrayDPvaryingVCPUSingleServer(5:5:end, :).*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanEnergyDPRuntimeVaryingVCPUSingleServer = sum(energyArrayDPRuntimeVaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanEnergyRandomVaryingVCPUSingleServer = sum(energyArrayRandomVaryingVCPUSingleServer.*succArrayRandomVaryingVCPUSingleServer, 2)./sum(succArrayRandomVaryingVCPUSingleServer, 2);
meanEnergyGreedy1VaryingVCPUSingleServer = sum(energyArrayGreedy1VaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanEnergyGreedy2VaryingVCPUSingleServer = sum(energyArrayGreedy2VaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);

meanComTimeDPvaryingVCPUSingleServer = sum(comTimeArrayDPvaryingVCPUSingleServer(5:5:end, :).*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanComTimeDPRuntimeVaryingVCPUSingleServer = sum(comTimeArrayDPRuntimeVaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanComTimeRandomVaryingVCPUSingleServer = sum(comTimeArrayRandomVaryingVCPUSingleServer.*succArrayRandomVaryingVCPUSingleServer, 2)./sum(succArrayRandomVaryingVCPUSingleServer, 2);
meanComTimeGreedy1VaryingVCPUSingleServer = sum(comTimeArrayGreedy1VaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);
meanComTimeGreedy2VaryingVCPUSingleServer = sum(comTimeArrayGreedy2VaryingVCPUSingleServer.*succArrayGreedy1VaryingVCPUSingleServer, 2)./sum(succArrayGreedy1VaryingVCPUSingleServer, 2);

meanEnergyResult = [(10:10:100)', meanEnergyDPvaryingVCPUSingleServer, meanEnergyDPRuntimeVaryingVCPUSingleServer, ...
    meanEnergyRandomVaryingVCPUSingleServer, meanEnergyGreedy1VaryingVCPUSingleServer, meanEnergyGreedy2VaryingVCPUSingleServer];
succResult = [(10:10:100)', sum(succArrayDPvaryingVCPUSingleServer(5:5:end, :), 2), sum(succArrayDPRuntimeVaryingVCPUSingleServer, 2), ...
    sum(succArrayRandomVaryingVCPUSingleServer, 2), sum(succArrayGreedy1VaryingVCPUSingleServer, 2), sum(succArrayGreedy2VaryingVCPUSingleServer, 2), ];
meanComTimeResult = [(10:10:100)', meanComTimeDPvaryingVCPUSingleServer, meanComTimeDPRuntimeVaryingVCPUSingleServer, ...
    meanComTimeRandomVaryingVCPUSingleServer, meanComTimeGreedy1VaryingVCPUSingleServer, meanComTimeGreedy2VaryingVCPUSingleServer];

%% varying servers
clc
clear
load('..\dp\energyArrayDPvaryingServers');
load('..\dp\succArrayDPvaryingServers');
load('..\dp\comTimeArrayDPvaryingServers');

load('..\dpRuntime\energyArrayDPRuntimeVaryingServers');
load('..\dpRuntime\succArrayDPRuntimeVaryingServers');
load('..\dpRuntime\comTimeArrayDPRuntimeVaryingServers');

load('..\random\energyArrayDPRandomVaryingServers');
load('..\random\succArrayDPRandomVaryingServers');
load('..\random\comTimeArrayDPRandomVaryingServers');

load('..\greedy1\energyArrayGreedyOneVaryingServers');
load('..\greedy1\succArrayGreedyOneVaryingServers');
load('..\greedy1\comTimeArrayGreedyOneVaryingServers');

load('..\greedy2\energyArrayGreedyTwoVaryingServers');
load('..\greedy2\succArrayGreedyTwoVaryingServers');
load('..\greedy2\comTimeArrayGreedyTwoVaryingServers');

succArray = succArrayDPvaryingServers.*succArrayDPRuntimeVaryingServers.*succArrayGreedyOneVaryingServers.*succArrayGreedyOneVaryingServers;

meanEnergyDPvaryingServers = sum(energyArrayDPvaryingServers.*succArray, 2)./sum(succArray, 2);
meanEnergyDPRuntimeVaryingServers = sum(energyArrayDPRuntimeVaryingServers.*succArray, 2)./sum(succArray, 2);
meanEnergyRandomVaryingServers = sum(energyArrayDPRandomVaryingServers.*succArrayDPRandomVaryingServers, 2)./sum(succArrayDPRandomVaryingServers, 2);
meanEnergyGreedy1VaryingServers = sum(energyArrayGreedyOneVaryingServers.*succArray, 2)./sum(succArray, 2);
meanEnergyGreedy2VaryingServers = sum(energyArrayGreedyTwoVaryingServers.*succArray, 2)./sum(succArray, 2);

meanComTimeDPvaryingServers = sum(comTimeArrayDPvaryingServers.*succArray, 2)./sum(succArray, 2);
meanComTimeDPRuntimeVaryingServers = sum(comTimeArrayDPRuntimeVaryingServers.*succArray, 2)./sum(succArray, 2);
meanComTimeRandomVaryingServers = sum(comTimeArrayDPRandomVaryingServers.*succArrayDPRandomVaryingServers, 2)./sum(succArrayDPRandomVaryingServers, 2);
meanComTimeGreedy1VaryingServers = sum(comTimeArrayGreedyOneVaryingServers.*succArray, 2)./sum(succArray, 2);
meanComTimeGreedy2VaryingServers = sum(comTimeArrayGreedyTwoVaryingServers.*succArray, 2)./sum(succArrayGreedyOneVaryingServers, 2);

meanEnergyResult = [(1:1:10)', meanEnergyDPvaryingServers, meanEnergyDPRuntimeVaryingServers, ...
    meanEnergyRandomVaryingServers, meanEnergyGreedy1VaryingServers, meanEnergyGreedy2VaryingServers];
succResult = [(1:1:10)', sum(succArrayDPvaryingServers, 2), sum(succArrayDPRuntimeVaryingServers, 2), ...
    sum(succArrayDPRandomVaryingServers, 2), sum(succArrayGreedyOneVaryingServers, 2), sum(succArrayGreedyTwoVaryingServers, 2), ];
meanComTimeResult = [(1:1:10)', meanComTimeDPvaryingServers, meanComTimeDPRuntimeVaryingServers, ...
    meanComTimeRandomVaryingServers, meanComTimeGreedy1VaryingServers, meanComTimeGreedy2VaryingServers];
